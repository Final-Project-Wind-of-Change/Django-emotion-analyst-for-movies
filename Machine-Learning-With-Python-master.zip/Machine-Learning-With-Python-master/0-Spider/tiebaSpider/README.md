这两个文件夹下的爬虫都是为了实现爬取贴吧前三页帖子的发帖人和回帖人，spider1使用的是BeautifulSoup+urllib2，spider2使用的是scrapy


[ Scrapy 爬取百度贴吧指定帖子的发帖人和回帖人](http://blog.csdn.net/Gamer_gyt/article/details/75043398)


CSDN博客地址：
http://blog.csdn.net/gamer_gyt/

如有问题请联系：
QQ：1923361654
WeChat：gyt13342445911
Email：thinkgamer_gyt@gmail.com
